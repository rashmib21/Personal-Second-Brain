def chunk_text(text, chunk_size=500, overlap=100):

	# Return empty list if there is no text
	if not text:
		return []

	chunks = []
	step = chunk_size - overlap
	if step <= 0:
		step = chunk_size

	# Split text into overlapping chunks
	for i in range(0, len(text), step):
		chunk = text[i:i + chunk_size].strip()
		if chunk:
			chunks.append(chunk)

	return chunks
	