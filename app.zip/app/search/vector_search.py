
import os
from app.storage.lancedb_store import get_table
from app.embeddings.embedding_router import generate_embedding

def search(question, how_many_results=10):
	table = get_table()
	if table is None:
		print("LanceDB table is not available.")
		return []

	# Generate vector embedding for the user question
	print(f"Searching for: '{question}'")
	question_vector = generate_embedding("text", question)

	# Check if user explicitly asks about a specific indexed file (e.g. "momo.wav", "linux.pdf")
	question_lower = question.lower()
	df = table.to_pandas()

	target_path = None
	if not df.empty:
		for path_str in df['path'].unique():
			fname = os.path.basename(str(path_str)).lower()
			if fname in question_lower:
				target_path = path_str
				break

	# Perform semantic vector search using LanceDB
	try:
		if target_path:
			print(f"Filtering search for file: {os.path.basename(target_path)}")
			escaped_path = str(target_path).replace("'", "''")
			results = table.search(question_vector).where(f"path = '{escaped_path}'").metric("cosine").limit(how_many_results).to_list()
		else:
			results = table.search(question_vector).metric("cosine").limit(how_many_results).to_list()

		print(f"Found {len(results)} matching chunks")
		return results
	except Exception as e:
		print(f"Search Error: {e}")
		return []


if __name__=="__main__":
	
	while True: 
		question=input("Ask: ")
		matching_chunks=search(question)
		print("\nTop Results\n")

		if not matching_chunks:
			print("No matching documents found.")

		for position, chunk in enumerate(matching_chunks, start=1):
			print("="*100)
			print(f"Result {position}")
			print("Path: ",chunk["path"])
			print("Type: ",chunk["file_type"])
			print("Score: ",chunk["_distance"])

			print("\nText: ")
			print("="*100)
			print(chunk["text"])
			print()	
